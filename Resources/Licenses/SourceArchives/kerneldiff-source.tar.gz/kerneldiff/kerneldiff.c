// from https://github.com/verygenericname/SSHRD_Script/commit/708ce254fea08e442ecb4cd20c3fdbfe6ce9ab66

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_DIFFS 16384

void print_usage(const char *prog_name) {
    printf("Usage: %s kernelcache_original kernelcache_patched output.bpatch\n", prog_name);
}

int main(int argc, char *argv[]) {
    if (argc < 4) {
        print_usage(argv[0]);
        return 0;
    }

    const char *original_path = argv[1];
    const char *patched_path = argv[2];
    const char *output_path = argv[3];

    FILE *f_orig = fopen(original_path, "rb");
    FILE *f_patch = fopen(patched_path, "rb");
    if (!f_orig || !f_patch) {
        fprintf(stderr, "Error opening input files.\n");
        return 1;
    }

    fseek(f_orig, 0, SEEK_END);
    fseek(f_patch, 0, SEEK_END);
    long size_orig = ftell(f_orig);
    long size_patch = ftell(f_patch);
    rewind(f_orig);
    rewind(f_patch);

    if (size_orig != size_patch) {
        fprintf(stderr, "Size does not match, can't compare files! Exiting...\n");
        fclose(f_orig);
        fclose(f_patch);
        return 1;
    }

    unsigned char *buf_orig = malloc(size_orig);
    unsigned char *buf_patch = malloc(size_patch);

    if (!buf_orig || !buf_patch) {
        fprintf(stderr, "Memory allocation failed.\n");
        fclose(f_orig);
        fclose(f_patch);
        return 1;
    }

    fread(buf_orig, 1, size_orig, f_orig);
    fread(buf_patch, 1, size_patch, f_patch);
    fclose(f_orig);
    fclose(f_patch);

    FILE *f_out = fopen(output_path, "w");
    if (!f_out) {
        fprintf(stderr, "Error opening output file.\n");
        free(buf_orig);
        free(buf_patch);
        return 1;
    }

    fprintf(f_out, "#AMFI\n\n");

    int diff_count = 0;

    for (long i = 0; i < size_orig; ++i) {
        if (buf_orig[i] != buf_patch[i]) {
            fprintf(f_out, "0x%lx 0x%02x 0x%02x\n", i, buf_orig[i], buf_patch[i]);
            printf("0x%lx 0x%02x 0x%02x\n", i, buf_orig[i], buf_patch[i]);
            diff_count++;
            if (diff_count >= MAX_DIFFS) {
                fprintf(stderr, "Too many differences, only a maximum of %d 8-byte differences are supported.\n", MAX_DIFFS);
                fclose(f_out);
                free(buf_orig);
                free(buf_patch);
                return 1;
            }
        }
    }

    fclose(f_out);
    free(buf_orig);
    free(buf_patch);
    return 0;
}

